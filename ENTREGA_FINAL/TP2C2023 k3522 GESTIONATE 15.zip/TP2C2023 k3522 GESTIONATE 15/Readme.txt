Curso: K3522
Número de grupo: 15
Integrantes:
    - Matias Nahuel Cotens - 2026820
    - Joaquin Menazzi - 1761316
    - Mateo Bertogliati - 2034130
    - Ignacio Kennedy - 1752613
Email del responsable: mcotens@frba.utn.edu.ar